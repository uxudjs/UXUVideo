# SPEC 第 21 节执行状态账本

状态：**APPROVED / READY FOR BUILD**

- 绑定计划：`work-products/plan.md`
- 计划 SHA-256：`b18979bf53a2c587278351d198ca6f27c173c3888d3da4eba53ba19d65bb69db`
- 计划模式：`fast = false`
- 安全并发上限：`1`
- 唯一写入者：主代理
- 当前批准：用户于 2026-08-19 明确批准完整计划 SHA `b18979bf53a2c587278351d198ca6f27c173c3888d3da4eba53ba19d65bb69db`
- 替代关系：前一批准 SHA `096e92fd1b7e084f118dd6939216003ace104ee9a7ad76155595ab38bbd8a77b` 因 T02 的版本无关职责与 T03 的 API 2 manifest fixture 职责互锁而停止；`8df83634738324bd4b1277d55a9204b5f4ea8a92dbc28fd9b064a7bfec59ee6e` 与 `6ef4a9515b3929695b04b0886b3fca64680dce765b0a7f5f16dd6ceba64cd91a` 继续作为更早历史证据保留
- 当前执行：`S21-T08` attempt 1 `failed`（完整 E2E 95/119；只读 Section 21 flows 仍绑定 API 1 fixture，任务边界冲突）

## 状态合同

允许状态为 `pending`、`in_progress`、`blocked`、`failed`、`completed`。每个任务的显式 `state` 是权威值；checkbox 是同一次原子更新产生的派生镜像，只有 `completed` 可勾选。依赖、写集、串行屏障、回滚与解锁条件只引用绑定计划第 2、4、7、8 节，不在本账本复制。当前计划 SHA 已批准且计划字节不可变；任务仍只可由已调用的实现流程按依赖串行启动。

## Serial 0

- [x] `S21-T01`｜state: `completed`｜deps: `none`｜修复基线身份并重新冻结跨仓合同

## Serial 1

- [x] `S21-T02`｜state: `completed`｜deps: `S21-T01`｜Worker 根路由合同复验

## Serial 2

- [x] `S21-T06`｜state: `completed`｜deps: `S21-T01`｜Liquid Glass 基础材质与可访问性降级复验

## Serial 3

- [x] `S21-T03`｜state: `completed`｜deps: `S21-T02`｜Worker 来源所有权与 IPTV 后端退役

## Serial 4

- [x] `S21-T05`｜state: `completed`｜deps: `S21-T02,S21-T06`｜Pages 根入口、角落状态与窗口生命周期

## Serial 5

- [x] `S21-T04`｜state: `completed`｜deps: `S21-T03`｜Worker 单来源 8 秒放弃与局部成功

## Serial 6

- [x] `S21-T07`｜state: `completed`｜deps: `S21-T05,S21-T06`｜搜索合并、卡片动作与折叠工具栏

## Serial 7

- [ ] `S21-T08`｜state: `failed`｜deps: `S21-T03,S21-T05,S21-T06`｜Pages 系统默认与 IPTV 运行表面退役

## Serial 8

- [ ] `S21-T09`｜state: `pending`｜deps: `S21-T08`｜统一视频源与用户弹幕 API 管理

## Serial 9

- [ ] `S21-T10`｜state: `pending`｜deps: `S21-T09`｜设置页六域信息架构与响应式控件

## Serial 10

- [ ] `S21-T11`｜state: `pending`｜deps: `S21-T10`｜逐视频片头片尾规则与同步迁移

## Serial 11

- [ ] `S21-T12`｜state: `pending`｜deps: `S21-T05,S21-T06,S21-T11`｜播放器影院布局、顶栏与网页全视窗

## Serial 12

- [ ] `S21-T13`｜state: `pending`｜deps: `S21-T07,S21-T10,S21-T12`｜其余页面与弹层材质收敛

## Serial 13

- [ ] `S21-T14`｜state: `pending`｜deps: `S21-T04,S21-T08,S21-T13`｜README、版本与双仓发布合同同步

## Serial 14

- [ ] `S21-T15`｜state: `pending`｜deps: `S21-T14`｜全量本地、浏览器视觉与发布前 HOLD 门

## 审批与远程边界

当前计划已按完整 SHA 明确批准，并通过既有 `@uxu-code:build auto` 调用进入本地串行实现。批准与实现调用均不授权 commit、push、PR、GitHub Pages 发布、Cloudflare 部署、D1/Secret 变更或生产结论。T15 的用户视觉批准也是本地候选门，不自动扩大远程权限。
